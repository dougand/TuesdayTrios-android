package com.oakcottagestudios.batleague;

/**
 * Created by Doug on 18/02/2015.
 */
public interface DownloadListener
{
	public void downloadStateChanged( int senderID, int newState );

}
